@echo off
setlocal
set "HELPER_DIR=%~dp0"
set "HELPER_PS1=%HELPER_DIR%BiliFetch-LocalHelper.ps1"
set "LOG=%HELPER_DIR%BiliFetch-startup-diagnosis.log"
title BiliFetch Local Helper Diagnosis

echo Creating diagnosis log...
(
  echo ========================================
  echo BiliFetch Local Helper Diagnosis
  echo ========================================
  echo Time: %date% %time%
  echo Helper folder: %HELPER_DIR%
  echo User: %username%
  echo.
) > "%LOG%"

if not exist "%HELPER_PS1%" (
  (
    echo [ERROR] Missing BiliFetch-LocalHelper.ps1.
    echo.
    echo How to fix:
    echo 1. Unzip the helper zip first.
    echo 2. Open the unzipped helper folder.
    echo 3. Run the start or diagnosis bat file again.
    echo.
  ) >> "%LOG%"
  type "%LOG%"
  echo.
  pause
  exit /b 1
)

where powershell >> "%LOG%" 2>&1
if errorlevel 1 (
  (
    echo.
    echo [ERROR] Windows PowerShell was not found.
    echo Please send this log to the author.
    echo.
  ) >> "%LOG%"
  type "%LOG%"
  echo.
  pause
  exit /b 1
)

(
  echo.
  echo [CHECK] Running helper self test...
) >> "%LOG%"

powershell -NoProfile -ExecutionPolicy Bypass -File "%HELPER_PS1%" -SelfTest >> "%LOG%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

(
  echo.
  echo [RESULT] Self test exit code: %EXIT_CODE%
  echo.
  echo Notes:
  echo - "Self test passed" means the helper script can run.
  echo - "ffmpeg.exe not found" means merge will fail until ffmpeg.exe is placed in this folder or added to PATH.
  echo - If the window still closes, send this log to the author.
) >> "%LOG%"

type "%LOG%"
echo.
echo Diagnosis log created:
echo %LOG%
pause
endlocal
